app.controller("vendorCtrl", function ($scope,$window,$http) {

});

