<h1>List of Customers</h1>
<h3>London is the capital city of England.</h3>
<p>It is the most populous city in the United Kingdom, with a metropolitan area of over 13 million inhabitants.</p>
<p>Search <i class="fas fa-search"></i> <input style="color: red" type="text" ng-model="searchKeyword"></p>
<table class="table-responsive table table-bordered" id="person-table">
  <tr>
    <th ng-click="orderByMe('SL')">SL</th>
    <th ng-click="orderByMe('Name')">Name</th>
    <th ng-click="orderByMe('Mobile')">Mobile</th>
    <th ng-click="orderByMe('Sex')">Sex</th>
    <th ng-click="orderByMe('Sex')">Action</th>
  </tr>
  <tr ng-repeat="x in myData | filter: searchKeyword | orderBy:myOrderBy" id="{{'row_id_'+x.SL}}">
    <td>{{ $index + 1 }}</td>
    <td ng-if="$odd" style="background-color:#9acfea">{{ x.Name | uppercase }}</td>
    <td ng-if="$even" style="background-color:#2aabd2">{{ x.Name | uppercase }}</td>
    <td ng-if="$odd" style="background-color:#9acfea">{{ x.Mobile }}</td>
    <td ng-if="$even" style="background-color:#2aabd2">{{ x.Mobile }}</td>
    <td ng-if="$odd" style="background-color:#9acfea">{{ x.Sex }}</td>
    <td ng-if="$even" style="background-color:#2aabd2">{{ x.Sex }}</td>
    <td ng-if="$odd" style="background-color:#9acfea"><span ng-click="removeItem({{x.SL}})"><i class="fas fa-trash-alt"></i></span></td>
    <td ng-if="$even" style="background-color:#2aabd2"><span ng-click="removeItem($index)"><i class="fas fa-trash-alt"></i></span></td>

  </tr>
</table>
<p>{{msg}}</p>