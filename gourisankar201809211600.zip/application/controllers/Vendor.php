<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Vendor extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->library('session');
        $this -> load -> model('person');
        $this -> is_logged_in();
    }
    function is_logged_in() {
		$is_logged_in = $this -> session -> userdata('is_logged_in');
		if (!isset($is_logged_in) || $is_logged_in != 1) {
			echo 'you have no permission to use developer area'. '<a href="">Login</a>';
            print_r($this->session->all_userdata());
			die();
		}
	}
	public function get_districts(){
	    $post_data =(object)json_decode(file_get_contents("php://input"), true);

        $state_id=$post_data->stateID;
	      $result=$this->person->select_districts($state_id)->result_array();
          $report_array['records']=$result;
          echo json_encode($report_array);
	}
	public function get_states(){
	      $result=$this->person->select_states()->result_array();
          $report_array['records']=$result;
          echo json_encode($report_array);


	}
	public function get_vendors(){
	    $result=$this->person->select_vendors()->result_array();
	    $report_array['records']=$result;
        echo json_encode($report_array);
	}
    public function angular_view_vendor(){
        ?>
                <style type="text/css">
                    .navbar-fixed-top {
                        border: none;
                        background: #ac2925;

                        margin-top: -20px;
                    }
                    .navbar-fixed-top a{
                        color: #a6e1ec;
                    }
                    #vendor-div{
                        margin-top: 0px;
                    }
                    h1{
                        color: blue;
                    }
                    #mySidenav a[ng-click]{
                        cursor: pointer;
                        position: absolute;
                        left: -20px;
                        transition: 0.3s;
                        padding: 15px;
                        width: 140px;
                        text-decoration: none;
                        font-size: 15px;
                        color: white;
                        border-radius: 0 5px 5px 0;
                        background-color: #ac2925;
                    }

                    #mySidenav a[ng-click]:hover {
                        left: 0;
                    }

                    #mySidenav a:hover {
                        left: 0;
                    }
                    #new-vendor {
                        top: 20px;
                        background-color: #4CAF50;
                    }

                    #update-vendor {
                        top: 78px;
                        background-color: #2196F3;
                    }

                    #show-vendor{
                        top: 136px;
                        background-color: #f44336;
                    }
                    #main-working-div h1{
                        color: darkblue;
                    }
                    #vendor-form input{
                        border-radius: 5px;
                    }
                    #vendorForm{
                        margin-top: 10px;
                     }
                     input.ng-invalid {
                        background-color: pink;
                    }
    </style>
    <div class="container-fluid">
        <div class="row">
            {{vendorForm.$pristine}}
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" id="vendor-div">
                <!-- Nav tabs -->
                <ul class="nav nav-tabs nav-justified indigo" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link " data-toggle="tab" href="#" role="tab" ng-click="setTab(1)"><i class="fa fa-user" ></i> New Vendor</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#" role="tab" ng-click="setTab(2)"><i class="fa fa-heart"></i> Vendor List</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#" role="tab" ng-click="setTab(3)"><i class="fa fa-envelope"></i>Update Vendors</a>
                    </li>
                </ul>
                <!-- Tab panels -->
                <div class="tab-content">
                    <!--Panel 1-->
                    <div ng-show="isSet(1)">
                        <div id="my-tab-1">
                            <form name="student_form">
                                <div class="row col-12">
                                    <div class="col-6 left-div">
                                        <div class="row col-12 mt-1">
                                            <label class="col-4">Vendor Id <span class="text-danger">*</span></label>
                                            <input class="col-6" type="text" ng-model="student.student_code" placeholder="Student Code" required>
                                        </div>
                                        <div class="row col-12 mt-1">
                                            <label class="col-4">Vendor Name <span class="text-danger">*</span></label>
                                            <input class="col-6" type="text" placeholder="Student Name" ng-model="student.student_name" required>
                                        </div>
                                        <div class="row col-12 mt-1">
                                            <label class="col-4">Mailing Name <span class="text-danger">*</span></label>
                                            <input class="col-6" type="text" placeholder="Student Name" ng-model="student.student_name" required>
                                        </div>
                                        <div class="row col-12 mt-1">
                                            <label class="col-4">Email</label>
                                            <input type="text" name="myField"  maxlength="5" class="col-6" ng-model="student.email_id">
                                        </div>
                                        <div class="row col-12 mt-1">
                                            <label class="col-4">Contact No 1 <span class="text-danger">*</span></label>
                                            <input type="text" class="col-6" ng-model="student.contact_1">
                                        </div>
                                        <div class="row col-12 mt-1">
                                            <label class="col-4">Contact No 2</label>
                                            <input type="text" class="col-6" ng-model="student.contact_2">
                                        </div>
                                        <div class="row col-12 mt-1">
                                            <label class="col-4">Aadhar No</label>
                                            <input type="text" class="col-6" ng-model="student.aadhar_number">
                                        </div>
                                        <div class="row col-12 mt-1">
                                            <label class="col-4">Pan No</label>
                                            <input type="text" class="col-3" name="pan" ng-model="student.pan_number" ng-pattern="/^[a-zA-Z]{5}[0-9]{4}[a-zA-Z]{1}$/">
                                            <div class="col-5" ng-messages="student_form.pan.$error" role="alert">
                                                <div class="text-danger" ng-message-exp="['pattern']">Check format AAAAA9999A</div>
                                            </div>
                                        </div>
                                        <div class="row col-12 mt-1">
                                            <label class="col-4">GST No</label>
                                            <input type="text" class="col-3" name="pan" ng-model="student.pan_number" ng-pattern="/^[a-zA-Z]{5}[0-9]{4}[a-zA-Z]{1}$/">
                                            <div class="col-5" ng-messages="student_form.pan.$error" role="alert">
                                                <div class="text-danger" ng-message-exp="['pattern']">Check format AAAAA9999A</div>
                                            </div>
                                        </div>
                                        <div class="row col-12"></div>
                                    </div>
                                    <div class="col-6 right-div">
                                        <div class="row col-12 mt-2">
                                            <label class="col-4">Address <span class="text-danger">*</span></label>
                                            <input class="col-6" type="text" name="address" ng-model="student.address" required>
                                            <div class="col-2" ng-messages="student_form.address.$error" role="alert">
                                                <div ng-message-exp="['required']">This is required</div>
                                            </div>
                                        </div>

                                        <div class="row col-12 mt-1">
                                            <label class="col-4">Area</label>
                                            <input class="col-6" type="text" ng-model="student.area">
                                        </div>
                                        <div class="row col-12 mt-1">
                                            <label class="col-4">City</label>
                                            <input class="col-6" type="text" ng-model="student.city">
                                        </div>
                                        <div class="row col-12 mt-1">
                                            <label class="col-4">City</label>
                                            <input class="col-6" type="text" ng-model="student.city">
                                        </div>
                                        <div class="row col-12 mt-1">
                                            <label class="col-4">Post office</label>
                                            <input class="col-4" type="text" ng-model="student.pin">
                                        </div>
                                        <div class="row col-12 mt-1">
                                            <label class="col-4">District</label>
                                            <select class="col-6"
                                                    ng-model="student.district"
                                                    ng-options="district as district.district_name for district in allDistricts"
                                            ></select>
                                        </div>
                                        <div class="row col-12 mt-1">
                                            <label class="col-4">State</label>
                                            <select class="col-6"
                                                    ng-model="student.state"
                                                    ng-options="state as state.state_name for state in allStates"
                                            ></select>
                                        </div>
                                        <div class="row col-12">
                                            <div class="row col-6 mt-1">
                                                <input type="submit" value="Save" ng-click="saveStudent(student)" ng-disabled="student_form.$invalid">{{student_form.$invalid}}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row col-12">
                                    <div class="col-6">
                                        <input type="file" fileinput="file" filepreview="filepreview"/>
                                    </div>
                                    <div class="col-6">
                                        <img ng-src="{{filepreview}}" class="img-responsive" ng-show="filepreview"/>
                                    </div>
                                </div>
                            </form>
                        </div> <!--//End of my tab1//-->
                    </div>
                    <!--/.Panel 1-->
                    <!--Panel 2-->
                    <div ng-show="isSet(2)">
                        <style type="text/css">
                            .bee{
                                background-color: #d9edf7;
                            }
                            .banana{
                                background-color: #c4e3f3;
                            }
                            #vendor-table-div table th{
                                background-color: #1b6d85;
                                color: #a6e1ec;
                                cursor: pointer;
                            }
                            a[ng-click]{
                                cursor: pointer;
                            }

                        </style>
                        <p><input type="text" ng-model="searchItem"><span class="glyphicon glyphicon-search"></span> Search </p>
                        <div id="vendor-table-div">
                            <table cellpadding="0" cellspacing="0" class="table table-bordered">
                                <tr>
                                    <th>SL></th>
                                    <th ng-click="changeSorting('person_id')">ID<i class="glyphicon" ng-class="getIcon('person_id')"></i></th>
                                    <th ng-click="changeSorting('person_name')">Name<i class="glyphicon" ng-class="getIcon('person_name')"></i></th>
                                    <th ng-click="changeSorting('mobile_no')">Mobile<i class="glyphicon" ng-class="getIcon('mobile_no')"></i></th>
                                    <th ng-click="changeSorting('address1')">Address<i class="glyphicon" ng-class="getIcon('address1')"></i></th>
                                    <th ng-click="changeSorting('gst_number')">GST no<i class="glyphicon" ng-class="getIcon('gst_number')"></i></th>
                                    <th ng-click="changeSorting('aadhar_no')">AAdhar No<i class="glyphicon" ng-class="getIcon('aadhar_no')"></i></th>
                                    <th ng-click="changeSorting('pan_no')">PAN No<i class="glyphicon" ng-class="getIcon('pan_no')"></i></th>
                                    <th>Edit</th>
                                </tr>
                                <tbody ng-repeat="vendor in vendorList | filter : searchItem  | orderBy:sort.active:sort.descending">
                                <tr ng-class-even="'banana'" ng-class-odd="'bee'">
                                    <td>{{ $index+1}}</td>
                                    <td>{{vendor.person_id}}</td>
                                    <td>{{vendor.person_name}}</td>
                                    <td>{{vendor.mobile_no}}</td>
                                    <td>{{vendor.address1}}</td>
                                    <td>{{vendor.gst_number}}</td>
                                    <td>{{vendor.aadhar_no}}</td>
                                    <td>{{vendor.pan_no}}</td>
                                    <td ng-click="updateVendorFromTable(vendor)"><a href="#"><i class="glyphicon glyphicon-edit"></i></a></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>

<!--                        <pre>vendor List = {{vendorList | json}}</pre>-->
<!--                        <pre>vendor = {{vendor | json}}</pre>-->
<!--                        <pre>vendors = {{vendorList | json}}</pre>-->
                    </div>
                    <!--/.Panel 2-->
                    <!--Panel 3-->
                    <div ng-show="isSet(3)">
                        This is our help area
                    </div>
                    <!--/.Panel 3-->
                </div>
            </div>

        </div>
    </div>







        <?php
    }
    public function new_vendor_form(){
        ?>
        <form>
            <input type="text" name="firstName" ng-model="vendor.firstName"> First name <br/>
            <input type="text" name="lastName"  ng-model="vendor.lastName"> Last name <br/>
        </form>

        {{vendor.firstName}} {{vendor.lastName}}

        <div>

        </div>

        <?php

    }
    function insert_vendor(){
        $post_data =json_decode(file_get_contents("php://input"), true);
        $result=$this->person->insert_new_vendor((object)$post_data['vendor']);
        $report_array['records']=$result;
        echo json_encode($report_array);
    }
    function update_vendor_by_vendor_id(){
        $post_data =json_decode(file_get_contents("php://input"), true);
        $result=$this->person->update_vendor_by_vendor_id((object)$post_data['vendor']);
        $report_array['records']=$result;
        echo json_encode($report_array);
    }
}
?>